﻿using Microsoft.Toolkit.Mvvm.Messaging.Messages;
using segundaPraticaExamenFinal.modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace segundaPraticaExamenFinal.Servicios
{
    class ComponenteRequestMessage :RequestMessage<Componente>
    {

    }
}
